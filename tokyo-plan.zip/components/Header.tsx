import React from 'react';
import { Language, Theme } from '../types';
import { Sun, Moon } from 'lucide-react';

interface HeaderProps {
  theme: Theme;
  setTheme: (t: Theme) => void;
  language: Language;
  setLanguage: (l: Language) => void;
}

const Header: React.FC<HeaderProps> = ({ theme, setTheme, language, setLanguage }) => {
  return (
    <header className="sticky top-0 z-50 w-full bg-[#F8F7F4] dark:bg-[#121212] border-b border-neutral-200 dark:border-neutral-800 transition-colors duration-500">
      <div className="max-w-4xl mx-auto px-6 h-24 flex items-center justify-between">
        
        {/* Branding - Vertical/Traditional feel */}
        <div className="flex flex-col justify-center">
            <div className="flex items-center gap-3">
                {/* Logo Box: Indigo in Light, Gold in Dark */}
                <div className="w-8 h-8 bg-[#0f2350] dark:bg-[#d6ae5f] flex items-center justify-center text-[#F8F7F4] dark:text-[#121212] font-serif-jp font-bold text-lg select-none">
                    東
                </div>
                <h1 className="text-2xl font-bold font-serif-jp tracking-[0.2em] uppercase text-[#0f2350] dark:text-[#EAEAEA]">
                    Tokyo<span className="font-light text-neutral-600 dark:text-[#d6ae5f]">Plan</span>
                </h1>
            </div>
            <span className="text-[10px] tracking-[0.3em] font-serif-jp text-neutral-400 dark:text-neutral-500 ml-11 mt-1 uppercase">
                Est. 2026
            </span>
        </div>

        <div className="flex items-center gap-6">
          {/* Language Toggle - Text based */}
          <button
            onClick={() => setLanguage(language === 'en' ? 'zh-TW' : 'en')}
            className="font-serif-jp text-sm tracking-widest hover:text-[#0f2350] dark:hover:text-[#d6ae5f] text-neutral-500 dark:text-neutral-400 transition-colors relative group"
            aria-label="Toggle Language"
          >
            {language === 'en' ? '中文' : 'ENG'}
            <span className="absolute -bottom-1 left-0 w-0 h-px bg-[#0f2350] dark:bg-[#d6ae5f] transition-all group-hover:w-full"></span>
          </button>

          {/* Theme Toggle - Minimalist */}
          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="text-neutral-400 hover:text-[#0f2350] dark:hover:text-[#d6ae5f] transition-colors"
            aria-label="Toggle Theme"
          >
            {theme === 'dark' ? <Moon size={16} strokeWidth={1.5} /> : <Sun size={18} strokeWidth={1.5} />}
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;