import React, { useState, useEffect } from 'react';
import { Language, Theme, TripPlan, Coordinates, Activity, TransitInfo, TransportMode } from './types';
import { TRANSLATIONS, STATIC_TRIP_PLAN_EN, STATIC_TRIP_PLAN_ZH } from './constants';
import Header from './components/Header';
import MapComponent from './components/MapComponent';
import { MapPin, X, ArrowLeft, Clock, MapPinned, Lightbulb, ArrowDown, Footprints, ExternalLink, Train, Bus, Car, Plane, ChevronRight, Utensils, BedDouble, Star } from 'lucide-react';

const App: React.FC = () => {
  const [theme, setTheme] = useState<Theme>('dark');
  const [language, setLanguage] = useState<Language>('zh-TW'); 
  const [activeTab, setActiveTab] = useState<number>(0); 
  const [mapModal, setMapModal] = useState<{ isOpen: boolean; markers: any[]; center?: Coordinates }>({
    isOpen: false,
    markers: [],
  });
  const [selectedActivity, setSelectedActivity] = useState<Activity | null>(null);
  const [selectedTransit, setSelectedTransit] = useState<TransitInfo | null>(null);
  
  const t = TRANSLATIONS[language];
  const tripPlan: TripPlan = language === 'zh-TW' ? STATIC_TRIP_PLAN_ZH : STATIC_TRIP_PLAN_EN;

  const daysCount = tripPlan.days.length;
  const foodTabIndex = daysCount;
  const infoTabIndex = daysCount + 1;

  // Apply theme
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const openMap = (markers: any[], center?: Coordinates, e?: React.MouseEvent) => {
    e?.stopPropagation(); // Prevent triggering parent click if inside a card
    setMapModal({ isOpen: true, markers, center });
  };

  const closeMap = () => {
    setMapModal(prev => ({ ...prev, isOpen: false }));
  };
  
  const closeDetails = () => {
    setSelectedActivity(null);
  }

  const closeTransit = () => {
    setSelectedTransit(null);
  }

  // Helper to get thumbnail URL for Wikimedia images
  const getThumbnailUrl = (url: string) => {
    if (!url) return '';
    // Wikimedia Commons supports ?width=XXX for dynamic resizing
    if (url.includes('commons.wikimedia.org/wiki/Special:FilePath')) {
        return `${url}?width=300`;
    }
    return url;
  };

  // Helper for transport icons
  const getTransportIcon = (mode: TransportMode, size: number = 20) => {
      switch (mode) {
          case 'train':
          case 'subway':
              return <Train size={size} />;
          case 'bus':
              return <Bus size={size} />;
          case 'taxi':
              return <Car size={size} />;
          case 'flight':
              return <Plane size={size} />;
          case 'walk':
          default:
              return <Footprints size={size} />;
      }
  };

  const activeDay = activeTab < daysCount ? tripPlan.days[activeTab] : null;
  // Determine which image to show: Static only
  const currentHeroImage = selectedActivity ? selectedActivity.imageUrl : undefined;

  return (
    <div className={`min-h-screen transition-colors duration-500 font-sans flex flex-col selection:bg-[#0f2350] selection:text-white dark:selection:bg-[#d6ae5f] dark:selection:text-black
      ${theme === 'dark' ? 'bg-[#121212] text-[#EAEAEA]' : 'bg-[#F8F7F4] text-[#2D2D2D]'}`}>
      
      <Header theme={theme} setTheme={setTheme} language={language} setLanguage={setLanguage} />

      {/* Tab Navigation - Minimalist Rail */}
      <nav className="sticky top-24 z-40 bg-[#F8F7F4]/95 dark:bg-[#121212]/95 backdrop-blur-sm border-b border-neutral-200 dark:border-neutral-800 select-none">
        <div className="max-w-4xl mx-auto flex overflow-x-auto snap-x">
            {tripPlan.days.map((day, index) => (
              <button
                key={index}
                onClick={() => setActiveTab(index)}
                className={`
                  snap-start flex-none 
                  w-[28vw] md:w-[22vw] lg:flex-1 lg:w-auto
                  group relative py-5 transition-all outline-none cursor-pointer
                  ${activeTab === index 
                    ? 'text-[#0f2350] dark:text-[#d6ae5f]' 
                    : 'text-neutral-400 dark:text-neutral-600 hover:text-neutral-600 dark:hover:text-neutral-400'
                  }`}
              >
                <div className="flex flex-col items-center gap-1">
                   <span className={`text-[10px] uppercase tracking-[0.2em] font-medium transition-colors ${activeTab === index ? 'text-[#0f2350] dark:text-[#d6ae5f]' : ''}`}>
                     {t.days} 0{index + 1}
                   </span>
                   <span className="font-serif-jp text-sm whitespace-nowrap">{day.date.split('(')[0]}</span>
                </div>
                {/* Active Indicator - Top Border for "Tag" feel */}
                {activeTab === index && (
                  <div className="absolute top-0 left-0 w-full h-[2px] bg-[#0f2350] dark:bg-[#d6ae5f]" />
                )}
                {/* Vertical Divider */}
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-px h-8 bg-neutral-200 dark:bg-neutral-800" />
              </button>
            ))}
            
            {/* Dining Tab */}
            <button
                onClick={() => setActiveTab(foodTabIndex)}
                className={`
                  snap-start flex-none 
                  w-[28vw] md:w-[22vw] lg:flex-1 lg:w-auto
                  relative py-5 transition-all outline-none cursor-pointer
                  ${activeTab === foodTabIndex 
                    ? 'text-[#0f2350] dark:text-[#d6ae5f]' 
                    : 'text-neutral-400 dark:text-neutral-600 hover:text-neutral-600 dark:hover:text-neutral-400'
                  }`}
            >
               <div className="flex flex-col items-center gap-1">
                   <span className={`text-[10px] uppercase tracking-[0.2em] font-medium transition-colors ${activeTab === foodTabIndex ? 'text-[#0f2350] dark:text-[#d6ae5f]' : ''}`}>
                     Dining
                   </span>
                   <span className="font-serif-jp text-sm whitespace-nowrap">{language === 'zh-TW' ? '美食' : 'Food'}</span>
                </div>
                 {activeTab === foodTabIndex && (
                  <div className="absolute top-0 left-0 w-full h-[2px] bg-[#0f2350] dark:bg-[#d6ae5f]" />
                )}
                {/* Vertical Divider */}
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-px h-8 bg-neutral-200 dark:bg-neutral-800" />
            </button>

            {/* Stay/Info Tab */}
            <button
                onClick={() => setActiveTab(infoTabIndex)}
                className={`
                  snap-start flex-none 
                  w-[28vw] md:w-[22vw] lg:flex-1 lg:w-auto
                  relative py-5 transition-all outline-none cursor-pointer
                  ${activeTab === infoTabIndex 
                    ? 'text-[#0f2350] dark:text-[#d6ae5f]' 
                    : 'text-neutral-400 dark:text-neutral-600 hover:text-neutral-600 dark:hover:text-neutral-400'
                  }`}
            >
               <div className="flex flex-col items-center gap-1">
                   <span className={`text-[10px] uppercase tracking-[0.2em] font-medium transition-colors ${activeTab === infoTabIndex ? 'text-[#0f2350] dark:text-[#d6ae5f]' : ''}`}>
                     Info
                   </span>
                   <span className="font-serif-jp text-sm whitespace-nowrap">{language === 'zh-TW' ? '資訊' : 'Info'}</span>
                </div>
                 {activeTab === infoTabIndex && (
                  <div className="absolute top-0 left-0 w-full h-[2px] bg-[#0f2350] dark:bg-[#d6ae5f]" />
                )}
            </button>
        </div>
      </nav>

      <main className="max-w-4xl mx-auto px-6 py-6 w-full flex-grow">
        <div className="animate-[fadeIn_0.5s_ease-out]">
          
          {/* DAILY ITINERARY VIEW */}
          {activeTab < daysCount && activeDay && (
            <div className="space-y-10">
              {/* Day Header */}
              <header className="relative bg-[#E5E5E5] dark:bg-[#1A1A1A] py-8 px-6 md:px-10 mb-8 mx-[-24px] md:mx-0 md:rounded-lg overflow-hidden border-l-4 border-[#0f2350] dark:border-[#d6ae5f]">
                 {/* Decorative Background Number */}
                 <div className="absolute -right-4 -bottom-10 text-[140px] font-bold text-neutral-500/10 dark:text-neutral-500/5 select-none font-serif-jp leading-none pointer-events-none">
                    0{activeTab + 1}
                 </div>
                 
                 <div className="relative z-10 flex flex-col items-start">
                    <div className="flex items-center gap-3 mb-3">
                         <span className="inline-block px-2 py-1 bg-black dark:bg-[#d6ae5f] text-white dark:text-black text-[10px] font-bold tracking-widest uppercase shadow-sm">
                           {t.days} 0{activeTab + 1}
                         </span>
                         <span className="text-xs font-bold tracking-widest uppercase text-neutral-600 dark:text-neutral-400">
                           {activeDay.date}
                         </span>
                    </div>
                    <h2 className="text-3xl md:text-4xl font-serif-jp font-bold text-black dark:text-[#EAEAEA] leading-tight">
                       {activeDay.summary}
                    </h2>
                 </div>
              </header>

              {/* Timeline Items */}
              <div className="space-y-0 border-l border-neutral-200 dark:border-neutral-800 ml-4 md:ml-0">
                {activeDay.activities.map((act, actIdx) => (
                  <div key={actIdx} className="relative pl-8 md:pl-12 pb-2 last:pb-0">
                     
                     {/* Timeline Dot */}
                     <div className="absolute -left-[5px] top-1.5 w-[11px] h-[11px] bg-[#F8F7F4] dark:bg-[#121212] border border-neutral-300 dark:border-neutral-700 rounded-full flex items-center justify-center">
                        <div className={`w-[5px] h-[5px] rounded-full ${actIdx === 0 ? 'bg-[#0f2350] dark:bg-[#d6ae5f]' : 'bg-neutral-300 dark:bg-neutral-600'}`}></div>
                     </div>

                     <div className="group flex flex-col md:flex-row gap-6 items-start mb-12">
                        
                        {/* Time & Title Mobile View */}
                        <div className="flex-1 w-full md:w-auto">
                            <span className="inline-block text-xs font-bold text-[#0f2350] dark:text-[#d6ae5f] mb-1 font-mono tracking-wider">
                              {act.time}
                            </span>
                            <h3 
                              onClick={() => setSelectedActivity(act)}
                              className="text-xl font-bold mb-2 cursor-pointer hover:text-[#0f2350] dark:hover:text-[#d6ae5f] transition-colors decoration-1 underline-offset-4 hover:underline"
                            >
                              {act.activity}
                            </h3>
                            <div className="flex items-center gap-2 text-sm text-neutral-500 mb-3">
                                <MapPin size={14} className="flex-shrink-0" />
                                <span className="truncate">{act.locationName}</span>
                            </div>
                            <p className="text-sm leading-relaxed text-neutral-600 dark:text-neutral-300 line-clamp-2 md:line-clamp-none">
                              {act.description}
                            </p>
                        </div>

                         {/* Thumbnail Image - Clickable Card - ROUNDED + ARROW */}
                         <div 
                             onClick={() => setSelectedActivity(act)}
                             className="relative w-full md:w-32 h-32 md:h-24 flex-shrink-0 bg-neutral-200 dark:bg-neutral-800 cursor-pointer select-none rounded-2xl overflow-hidden group shadow-sm"
                          >
                             {/* Image with interaction hint */}
                             {act.imageUrl ? (
                                 <>
                                     <img 
                                         src={getThumbnailUrl(act.imageUrl)} 
                                         alt={act.locationName}
                                         loading="lazy"
                                         draggable="false"
                                         className="w-full h-full object-cover"
                                     />
                                     {/* Round arrow button mimicking transport card style */}
                                     <div className="absolute bottom-2 right-2 w-7 h-7 bg-[#0f2350] dark:bg-[#d6ae5f] rounded-full flex items-center justify-center shadow-md z-10">
                                         <ChevronRight size={16} className="text-white dark:text-black ml-0.5" />
                                     </div>
                                 </>
                             ) : (
                                 <div className="w-full h-full flex items-center justify-center text-neutral-400 relative">
                                     <MapPin size={24} strokeWidth={1} />
                                     <div className="absolute bottom-2 right-2 w-7 h-7 bg-[#0f2350] dark:bg-[#d6ae5f] rounded-full flex items-center justify-center shadow-md">
                                         <ChevronRight size={16} className="text-white dark:text-black ml-0.5" />
                                     </div>
                                 </div>
                             )}
                         </div>
                     </div>

                     {/* Transit Connector to Next Activity */}
                     {act.transitToNext && (
                         <div 
                            onClick={() => setSelectedTransit(act.transitToNext || null)}
                            className="mb-12 cursor-pointer select-none"
                         >
                             <div className="relative border border-dashed border-neutral-300 dark:border-neutral-700 bg-neutral-100/50 dark:bg-neutral-900/50 p-3 hover:bg-neutral-200 dark:hover:bg-neutral-800 transition-colors flex items-center gap-4 group">
                                 {/* Icon */}
                                 <div className="w-8 h-8 rounded-full bg-white dark:bg-black border border-neutral-200 dark:border-neutral-700 flex items-center justify-center text-neutral-500 group-hover:text-[#0f2350] dark:group-hover:text-[#d6ae5f] transition-colors">
                                     {getTransportIcon(act.transitToNext.options[0].mode, 14)}
                                 </div>
                                 
                                 <div className="flex-1">
                                    <div className="flex items-center justify-between">
                                        <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 group-hover:text-neutral-600 dark:group-hover:text-neutral-300 transition-colors">
                                            Next: {act.transitToNext.destination}
                                        </span>
                                        {/* Always Visible Transit Details Label */}
                                        <div className="flex items-center text-[#0f2350] dark:text-[#d6ae5f]">
                                            <span className="text-[10px] font-bold mr-1">{t.transitDetails}</span>
                                            <ArrowDown size={12} className="-rotate-90" />
                                        </div>
                                    </div>
                                    <p className="text-sm font-medium mt-0.5 text-neutral-700 dark:text-neutral-300">
                                        {act.transitToNext.summary}
                                    </p>
                                 </div>
                             </div>
                         </div>
                     )}

                  </div>
                ))}
              </div>
            </div>
          )}

          {/* FOOD / DINING TAB */}
          {activeTab === foodTabIndex && (
              <section className="animate-[fadeIn_0.5s_ease-out]">
                <div className="flex items-center gap-3 mb-8 border-b border-neutral-200 dark:border-neutral-800 pb-4">
                   <div className="w-10 h-10 bg-[#0f2350] dark:bg-[#d6ae5f] flex items-center justify-center text-white dark:text-black">
                      <Utensils size={20} />
                   </div>
                   <div>
                       <h3 className="text-2xl font-bold font-serif-jp">{t.restaurants}</h3>
                       <p className="text-sm text-neutral-500 dark:text-neutral-400">Curated dining experiences</p>
                   </div>
                </div>
                
                <div className="space-y-6">
                  {tripPlan.restaurants.map((rest, i) => (
                    <div key={i} className="group bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-lg overflow-hidden flex flex-col md:flex-row transition-all hover:border-[#0f2350] dark:hover:border-[#d6ae5f]">
                      
                      {/* Image Section */}
                      <div className="w-full md:w-1/3 h-48 md:h-auto relative bg-neutral-200 dark:bg-neutral-800 overflow-hidden">
                        {rest.imageUrl ? (
                           <img 
                              src={getThumbnailUrl(rest.imageUrl)} 
                              alt={rest.name}
                              loading="lazy"
                              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                              draggable="false"
                           />
                        ) : (
                           <div className="w-full h-full flex items-center justify-center text-neutral-400">
                             <Utensils size={32} strokeWidth={1} />
                           </div>
                        )}
                        {/* Cuisine Tag */}
                        <div className="absolute top-3 left-3 px-3 py-1 bg-black/70 backdrop-blur-sm text-white text-xs font-bold uppercase tracking-wider rounded-sm">
                           {rest.cuisine}
                        </div>
                      </div>

                      {/* Content Section */}
                      <div className="flex-1 p-6 flex flex-col justify-between">
                         <div>
                            <div className="flex justify-between items-start mb-2">
                               <h4 className="font-bold text-xl group-hover:text-[#0f2350] dark:group-hover:text-[#d6ae5f] transition-colors">{rest.name}</h4>
                               {rest.priceRange && (
                                   <span className="font-mono text-sm font-bold text-neutral-500">{rest.priceRange}</span>
                               )}
                            </div>
                            
                            {/* Tabelog Rating */}
                            {rest.tabelogRating && (
                                <div className="flex items-center gap-2 mb-3">
                                   <div className="flex items-center gap-1 text-[#ee5e27]">
                                      <Star size={16} fill="#ee5e27" strokeWidth={0} />
                                      <span className="font-bold text-lg leading-none">{rest.tabelogRating.toFixed(2)}</span>
                                   </div>
                                   <span className="text-xs text-neutral-400 font-medium">Tabelog Score</span>
                                </div>
                            )}

                            <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-4 leading-relaxed">{rest.description}</p>
                         </div>

                         {/* Actions */}
                         <div className="flex items-center gap-4 mt-2">
                            {/* Open Map Button */}
                            <button 
                               onClick={() => openMap([{ position: rest.coordinates, title: rest.name, description: rest.description }])}
                               className="flex items-center gap-2 px-4 py-2 text-xs font-bold uppercase tracking-wider border border-neutral-300 dark:border-neutral-700 rounded hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                            >
                               <MapPinned size={14} /> {t.viewMap}
                            </button>

                            {/* External Tabelog Link */}
                            {rest.tabelogUrl && (
                                <a 
                                   href={rest.tabelogUrl} 
                                   target="_blank" 
                                   rel="noopener noreferrer"
                                   className="flex items-center gap-2 px-4 py-2 text-xs font-bold uppercase tracking-wider bg-[#ee5e27] text-white rounded hover:bg-[#d44d1c] transition-colors"
                                >
                                   Tabelog <ExternalLink size={12} />
                                </a>
                            )}
                         </div>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
          )}

          {/* STAY & INFO TAB */}
          {activeTab === infoTabIndex && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-[fadeIn_0.5s_ease-out]">
              {/* Hotels Section */}
              <section>
                <div className="flex items-center gap-3 mb-6 border-b border-neutral-200 dark:border-neutral-800 pb-4">
                   <div className="w-10 h-10 bg-neutral-200 dark:bg-neutral-800 flex items-center justify-center text-[#0f2350] dark:text-[#d6ae5f]">
                      <BedDouble size={20} />
                   </div>
                   <div>
                       <h3 className="text-2xl font-bold font-serif-jp">{t.hotels}</h3>
                       <p className="text-sm text-neutral-500 dark:text-neutral-400">Where to stay</p>
                   </div>
                </div>
                <div className="space-y-6">
                  {tripPlan.hotels.map((hotel, i) => (
                    <div key={i} className="group cursor-pointer select-none pl-4 border-l-2 border-neutral-200 dark:border-neutral-800 hover:border-[#0f2350] dark:hover:border-[#d6ae5f] transition-colors" onClick={() => openMap([{ position: hotel.coordinates, title: hotel.name, description: hotel.description }])}>
                      <div className="flex justify-between items-start">
                        <h4 className="font-bold text-lg group-hover:text-[#0f2350] dark:group-hover:text-[#d6ae5f] transition-colors">{hotel.name}</h4>
                        <span className="text-sm font-mono text-neutral-500">{hotel.rating}★</span>
                      </div>
                      <p className="text-sm text-neutral-600 dark:text-neutral-400 mt-1 mb-2">{hotel.description}</p>
                      <div className="flex items-center gap-4 text-xs text-neutral-500">
                         <span className="font-medium text-[#0f2350] dark:text-[#d6ae5f]">{hotel.priceRange}</span>
                         <span className="flex items-center gap-1 hover:underline"><MapPinned size={12}/> {t.viewMap}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              {/* Transport Tips Section */}
              <section className="md:col-span-2 mt-4 bg-neutral-100 dark:bg-neutral-800/50 p-8 border border-neutral-200 dark:border-neutral-800 rounded-lg">
                <div className="flex items-center gap-3 mb-6">
                   <Lightbulb className="text-[#0f2350] dark:text-[#d6ae5f]" size={24} />
                   <h3 className="text-xl font-bold font-serif-jp">{t.tips}</h3>
                </div>
                 <ul className="space-y-4">
                    {tripPlan.transportTips.map((tip, i) => (
                        <li key={i} className="text-sm md:text-base text-neutral-700 dark:text-neutral-300 flex items-start gap-4">
                            <span className="block w-2 h-2 mt-2 bg-[#0f2350] dark:bg-[#d6ae5f] rounded-full flex-shrink-0" />
                            <span className="leading-relaxed">{tip}</span>
                        </li>
                    ))}
                 </ul>
              </section>
            </div>
          )}
        </div>
      </main>

      {/* Map Modal - z-[70] to appear above Details (z-50) */}
      {mapModal.isOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-[fadeIn_0.2s_ease-out]">
          <div className="relative w-full max-w-5xl h-[85vh] bg-[#F8F7F4] dark:bg-[#121212] shadow-2xl flex flex-col border border-neutral-200 dark:border-neutral-800">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 bg-[#F8F7F4] dark:bg-[#121212] border-b border-neutral-200 dark:border-neutral-800 z-10">
                <h3 className="font-bold text-lg font-serif-jp tracking-widest uppercase">{t.viewMap}</h3>
                <div className="flex items-center gap-4">
                   {/* Open in Google Maps Button */}
                   <a 
                      href={`https://www.google.com/maps/search/?api=1&query=${mapModal.center ? `${mapModal.center.lat},${mapModal.center.lng}` : (mapModal.markers.length > 0 ? `${mapModal.markers[0].position.lat},${mapModal.markers[0].position.lng}` : 'Tokyo')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold uppercase tracking-wider border border-[#0f2350] dark:border-[#d6ae5f] text-[#0f2350] dark:text-[#d6ae5f] hover:bg-[#0f2350] hover:text-white dark:hover:bg-[#d6ae5f] dark:hover:text-black transition-colors"
                   >
                      <span>Google Map</span>
                      <ExternalLink size={12} />
                   </a>

                   <button 
                      onClick={closeMap} 
                      className="p-2 hover:bg-neutral-200 dark:hover:bg-neutral-800 transition-colors"
                    >
                      <X size={20} />
                   </button>
                </div>
            </div>
            {/* Map Container */}
            <div className="flex-grow relative bg-neutral-100 dark:bg-neutral-900">
               <MapComponent 
                  markers={mapModal.markers} 
                  center={mapModal.center} 
                  theme={theme}
               />
            </div>
          </div>
        </div>
      )}

      {/* Activity Details Modal */}
      {selectedActivity && (
        <div className="fixed inset-0 z-50 flex flex-col bg-[#F8F7F4] dark:bg-[#121212] animate-[slideUp_0.3s_ease-out] overflow-y-auto">
             
             {/* Hero Image Section */}
             <div className="relative h-[40vh] w-full flex-shrink-0 bg-neutral-900">
                 {currentHeroImage ? (
                     <img 
                        src={currentHeroImage} 
                        alt={selectedActivity.locationName}
                        className="w-full h-full object-cover opacity-90"
                        draggable="false"
                     />
                 ) : (
                     <div className="w-full h-full flex items-center justify-center text-neutral-600">
                         <span className="text-6xl font-serif-jp opacity-20">東京</span>
                     </div>
                 )}
                 <button 
                    onClick={closeDetails}
                    className="absolute top-6 left-6 z-10 p-3 bg-white/10 backdrop-blur-md text-white hover:bg-white/20 transition-colors rounded-full"
                 >
                    <ArrowLeft size={24} />
                 </button>
                 <div className="absolute inset-0 bg-gradient-to-t from-[#F8F7F4] dark:from-[#121212] to-transparent pointer-events-none" />
                 
                 <div className="absolute bottom-6 left-6 right-6">
                     <span className="inline-block px-3 py-1 bg-[#0f2350] dark:bg-[#d6ae5f] text-white dark:text-black text-xs font-bold tracking-widest uppercase mb-3">
                         {selectedActivity.category}
                     </span>
                     <h1 className="text-3xl md:text-5xl font-bold font-serif-jp text-black dark:text-white leading-tight shadow-sm">
                         {selectedActivity.locationName}
                     </h1>
                 </div>
             </div>

             {/* Content Section */}
             <div className="flex-grow max-w-3xl mx-auto w-full px-6 py-10 space-y-10 pb-20">
                 
                 {/* Main Description */}
                 <div className="prose dark:prose-invert max-w-none">
                     <p className="text-lg md:text-xl leading-relaxed text-neutral-800 dark:text-neutral-200 font-medium">
                         {selectedActivity.extendedDescription || selectedActivity.description}
                     </p>
                 </div>

                 {/* Practical Info Grid */}
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6 border-t border-neutral-200 dark:border-neutral-800">
                     <div className="space-y-1">
                         <div className="flex items-center gap-2 text-[#0f2350] dark:text-[#d6ae5f] font-bold text-xs uppercase tracking-widest mb-1">
                             <Clock size={14} /> {t.hours}
                         </div>
                         <p className="text-neutral-700 dark:text-neutral-300">
                             {selectedActivity.openingHours || "N/A"}
                         </p>
                     </div>
                     <div className="space-y-1">
                         <div className="flex items-center gap-2 text-[#0f2350] dark:text-[#d6ae5f] font-bold text-xs uppercase tracking-widest mb-1">
                             <MapPin size={14} /> {t.address}
                         </div>
                         <p className="text-neutral-700 dark:text-neutral-300">
                             {selectedActivity.address || "N/A"}
                         </p>
                     </div>
                 </div>

                 {/* Tips Section */}
                 {selectedActivity.tips && (
                     <div className="bg-neutral-100 dark:bg-neutral-800/50 p-6 border-l-4 border-[#0f2350] dark:border-[#d6ae5f]">
                         <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                             <Lightbulb size={18} className="text-[#0f2350] dark:text-[#d6ae5f]" />
                             {t.tips}
                         </h3>
                         <ul className="space-y-2">
                             {selectedActivity.tips.map((tip, idx) => (
                                 <li key={idx} className="flex items-start gap-3 text-sm text-neutral-700 dark:text-neutral-300">
                                     <span className="block w-1.5 h-1.5 mt-1.5 bg-neutral-400 rounded-full flex-shrink-0" />
                                     {tip}
                                 </li>
                             ))}
                         </ul>
                     </div>
                 )}

                 {/* Map Preview */}
                 <div className="h-64 w-full bg-neutral-200 dark:bg-neutral-800 relative group cursor-pointer" 
                      onClick={() => openMap([{ position: selectedActivity.coordinates, title: selectedActivity.locationName, description: selectedActivity.description }])}>
                     <MapComponent 
                         markers={[{ position: selectedActivity.coordinates, title: selectedActivity.locationName }]} 
                         theme={theme}
                         zoom={15}
                     />
                     <div className="absolute bottom-4 right-4 bg-[#F8F7F4] dark:bg-[#121212] px-4 py-2 text-xs font-bold uppercase tracking-wider shadow-lg flex items-center gap-2">
                         <ExternalLink size={12} /> {t.viewMap}
                     </div>
                 </div>

             </div>
        </div>
      )}

      {/* Transit Details Modal */}
      {selectedTransit && (
        <div className="fixed inset-0 z-[60] flex items-end md:items-center justify-center bg-black/50 backdrop-blur-sm animate-[fadeIn_0.2s_ease-out]" onClick={closeTransit}>
             <div className="w-full md:max-w-md bg-[#F8F7F4] dark:bg-[#121212] md:rounded-lg shadow-2xl overflow-hidden flex flex-col max-h-[80vh]" onClick={e => e.stopPropagation()}>
                 <div className="p-4 border-b border-neutral-200 dark:border-neutral-800 flex items-center justify-between bg-neutral-50 dark:bg-neutral-900">
                     <h3 className="font-bold text-lg">{t.transitDetails}</h3>
                     <button onClick={closeTransit} className="p-1 hover:bg-neutral-200 dark:hover:bg-neutral-800 rounded-full">
                         <X size={20} />
                     </button>
                 </div>
                 
                 <div className="p-6 overflow-y-auto">
                     <div className="mb-6">
                         <div className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-1">Destination</div>
                         <div className="text-2xl font-serif-jp font-bold text-[#0f2350] dark:text-[#d6ae5f]">{selectedTransit.destination}</div>
                     </div>

                     <div className="space-y-4">
                         <div className="text-xs font-bold uppercase tracking-wider text-neutral-500 border-b border-neutral-200 dark:border-neutral-800 pb-2">{t.transitOptions}</div>
                         
                         {selectedTransit.options.map((opt, i) => (
                             <div key={i} className="flex flex-col gap-3 p-4 border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-black/40 hover:border-[#0f2350] dark:hover:border-[#d6ae5f] transition-colors group">
                                 <div className="flex gap-4">
                                    <div className="mt-1">
                                        <div className="w-10 h-10 rounded-full bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center text-[#0f2350] dark:text-[#d6ae5f]">
                                            {getTransportIcon(opt.mode, 20)}
                                        </div>
                                    </div>
                                    <div className="flex-1">
                                        <div className="flex justify-between items-start mb-1">
                                            <span className="font-bold text-base">{opt.name}</span>
                                            {opt.cost && <span className="text-sm font-mono bg-neutral-100 dark:bg-neutral-800 px-2 py-0.5 rounded">{opt.cost}</span>}
                                        </div>
                                        <div className="text-xs font-bold text-neutral-500 mb-2 flex items-center gap-1">
                                            <Clock size={10} /> {opt.duration}
                                        </div>
                                        <p className="text-sm text-neutral-600 dark:text-neutral-400 leading-snug">
                                            {opt.instructions}
                                        </p>
                                    </div>
                                 </div>
                                 
                                 {/* Related Image and Link */}
                                 {(opt.imageUrl || opt.officialUrl) && (
                                     <div className="mt-2 pl-[3.5rem] space-y-3">
                                        {opt.imageUrl && (
                                            <div className="w-full h-32 rounded-sm overflow-hidden bg-neutral-100 dark:bg-neutral-800 relative">
                                                <img 
                                                    src={getThumbnailUrl(opt.imageUrl)} 
                                                    alt={opt.name}
                                                    loading="lazy"
                                                    className="w-full h-full object-cover"
                                                    draggable="false"
                                                />
                                            </div>
                                        )}
                                        {opt.officialUrl && (
                                            <a 
                                                href={opt.officialUrl} 
                                                target="_blank" 
                                                rel="noopener noreferrer"
                                                className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-[#0f2350] dark:text-[#d6ae5f] hover:underline"
                                            >
                                                Official Website <ExternalLink size={10} />
                                            </a>
                                        )}
                                     </div>
                                 )}
                             </div>
                         ))}
                     </div>
                 </div>
             </div>
        </div>
      )}

    </div>
  );
};

export default App;