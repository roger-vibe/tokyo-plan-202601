import { Translations, TripPlan } from './types';

export const TRANSLATIONS: Record<string, Translations> = {
  en: {
    title: "Tokyo Journey 2026",
    subtitle: "January 23 - January 27",
    generateBtn: "Generate Itinerary",
    generating: "Planning your journey...",
    hotels: "Accommodations",
    restaurants: "Dining",
    itinerary: "Itinerary",
    transport: "Transport",
    viewMap: "View Map",
    closeMap: "Close Map",
    darkMode: "Dark",
    lightMode: "Light",
    days: "Day",
    readMore: "Read Details",
    address: "Address",
    hours: "Opening Hours",
    tips: "Traveler Tips",
    back: "Back",
    transitDetails: "Transit Details",
    transitOptions: "Available Options",
  },
  'zh-TW': {
    title: "東京之旅 2026",
    subtitle: "1月23日 - 1月27日",
    generateBtn: "生成行程",
    generating: "正在規劃您的旅程...",
    hotels: "住宿推薦",
    restaurants: "精選美食",
    itinerary: "每日行程",
    transport: "交通資訊",
    viewMap: "查看地圖",
    closeMap: "關閉地圖",
    darkMode: "深色",
    lightMode: "淺色",
    days: "第",
    readMore: "查看詳情",
    address: "地址",
    hours: "營業時間",
    tips: "旅遊貼士",
    back: "返回",
    transitDetails: "交通詳情",
    transitOptions: "可選方案",
  }
};

export const DEFAULT_COORDS = { lat: 35.6762, lng: 139.6503 };

export const STATIC_TRIP_PLAN_EN: TripPlan = {
  tripName: "Tokyo Journey 2026",
  transportTips: [
    "Purchase a Suica or Pasmo IC card immediately upon arrival at the airport for seamless travel on trains and buses.",
    "The 72-hour Tokyo Subway Ticket is highly recommended for this itinerary as it covers all metro lines.",
    "Download the 'Japan Travel by NAVITIME' app for accurate train schedules and platform information."
  ],
  hotels: [
    {
      name: "Keio Plaza Hotel Tokyo",
      description: "Luxury hotel in Shinjuku with stunning skyline views and easy airport bus access.",
      priceRange: "$$$",
      rating: "4.5",
      coordinates: { lat: 35.6896, lng: 139.6922 }
    },
    {
      name: "Hotel Gracery Shinjuku",
      description: "Mid-range hotel famous for the giant Godzilla head, located right in Kabukicho.",
      priceRange: "$$",
      rating: "4.2",
      coordinates: { lat: 35.6955, lng: 139.7018 }
    },
    {
      name: "The Millennials Shibuya",
      description: "Modern, high-tech capsule hotel offering a social atmosphere and great location.",
      priceRange: "$",
      rating: "4.4",
      coordinates: { lat: 35.6616, lng: 139.7005 }
    }
  ],
  restaurants: [
    {
      name: "Sushi no Midori",
      cuisine: "Sushi",
      description: "High-quality sushi at reasonable prices. Known for generous portion sizes and long queues.",
      priceRange: "$$",
      coordinates: { lat: 35.6596, lng: 139.6989 },
      tabelogRating: 3.58,
      tabelogUrl: "https://tabelog.com/en/tokyo/A1303/A130301/13004624/dtlphotolst/1/",
      imageUrl: "https://tblg.k-img.com/restaurant/images/Rvw/112660/640x640_rect_112660756.jpg"
    },
    {
      name: "Ichiran Ramen",
      cuisine: "Ramen",
      description: "Famous Tonkotsu ramen with individual booths. A must-visit for first-timers.",
      priceRange: "$",
      coordinates: { lat: 35.6926, lng: 139.7012 },
      tabelogRating: 3.08,
      tabelogUrl: "https://tabelog.com/en/tokyo/A1304/A130401/13192087/dtlphotolst/1/",
      imageUrl: "https://tblg.k-img.com/restaurant/images/Rvw/153169/640x640_rect_153169722.jpg"
    },
    {
      name: "Gonpachi Nishi-Azabu",
      cuisine: "Izakaya",
      description: "The 'Kill Bill' restaurant. Lively atmosphere with traditional wooden architecture.",
      priceRange: "$$$",
      coordinates: { lat: 35.6606, lng: 139.7238 },
      tabelogRating: 3.42,
      tabelogUrl: "https://tabelog.com/en/tokyo/A1307/A130701/13005298/dtlphotolst/3/",
      imageUrl: "https://tblg.k-img.com/restaurant/images/Rvw/248736/640x640_rect_6d32f903d38eb7ee6c263fb0185983fd.jpg"
    }
  ],
  days: [
    {
      date: "Jan 23 (Fri)",
      summary: "Arrival & Shinjuku Night",
      activities: [
        {
          time: "15:55 - 17:00",
          activity: "Landing",
          locationName: "Narita Airport T2",
          description: "Flight UO870 lands. Clear customs and pick up essentials.",
          extendedDescription: "Welcome to Tokyo! After landing at Narita Terminal 2, proceed through immigration. Collect your luggage and head to the arrival hall. This is the best time to pick up your Pocket Wi-Fi/SIM card and buy a Suica card from the JR East Travel Service Center.",
          address: "Narita International Airport Terminal 2",
          openingHours: "N/A",
          tips: ["Download the 'Japan Official Travel App' for train routes.", "Buy a bottle of green tea from a vending machine to start your trip."],
          category: "transport",
          coordinates: { lat: 35.7719, lng: 140.3928 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Narita_Airport_Terminal_2_Departure_Hall_2017.jpg",
          transitToNext: {
            summary: "Narita Express to Shinjuku",
            destination: "Shinjuku Station",
            options: [
              {
                mode: "train",
                name: "Narita Express (N'EX)",
                duration: "85 mins",
                cost: "¥3,250",
                instructions: "Follow red signs for JR Lines (B1F). Board N'EX bound for Shinjuku/Ikebukuro. All seats are reserved.",
                officialUrl: "https://www.jreast.co.jp/multi/en/nex/",
                imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/E259_Narita_Express.jpg"
              },
              {
                mode: "bus",
                name: "Airport Limousine Bus",
                duration: "100-120 mins",
                cost: "¥3,200",
                instructions: "Buy tickets at the orange counter in Arrival Hall. Bus drops directly at major hotels (Keio Plaza, Hilton, etc.).",
                officialUrl: "https://www.limousinebus.co.jp/guide/en/",
                imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Airport_Limousine_Bus_Mitsubishi_Fuso_Aero_Ace.jpg"
              }
            ]
          }
        },
        {
          time: "19:00 - 20:00",
          activity: "Check-in",
          locationName: "Shinjuku Hotel",
          description: "Arrive in Shinjuku, check into your hotel, and drop off bags.",
          extendedDescription: "Shinjuku Station is massive. Look for the 'West Exit' for the hotel shuttle buses or taxis if staying at Keio Plaza or similar large hotels. Once checked in, freshen up quickly before heading out for dinner.",
          address: "Nishi-Shinjuku, Shinjuku City, Tokyo",
          openingHours: "24 Hours",
          tips: ["Shinjuku station is complex; follow the colored overhead signs carefully."],
          category: "transport",
          coordinates: { lat: 35.6896, lng: 139.6922 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Shinjuku_by_night.jpg",
          transitToNext: {
            summary: "Walk to Omoide Yokocho",
            destination: "Omoide Yokocho",
            options: [
              {
                mode: "walk",
                name: "Walking",
                duration: "5-10 mins",
                instructions: "Head towards the West Exit of Shinjuku Station. Look for the uniqlo building, the alley entrance is nearby with green neons."
              }
            ]
          }
        },
        {
          time: "20:30 - 22:00",
          activity: "Late Dinner",
          locationName: "Omoide Yokocho",
          description: "Atmospheric narrow alleyway packed with tiny yakitori stalls and lanterns.",
          extendedDescription: "Known affectionately as 'Piss Alley', this narrow, lantern-lit lane teleports you back to post-war Tokyo. It is perfect for a late-night meal of Yakitori (grilled chicken) and beer after a long flight. The atmosphere is smoky, loud, and incredibly authentic.",
          address: "1-2 Nishishinjuku, Shinjuku City, Tokyo 160-0023",
          openingHours: "Most stalls open until 23:00 or Midnight",
          tips: ["Most stalls are cash only.", "Cover charge (otohshi) is common."],
          category: "food",
          coordinates: { lat: 35.6931, lng: 139.6999 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Omoide_Yokocho,_Shinjuku_(42384563020).jpg"
        }
      ]
    },
    {
      date: "Jan 24 (Sat)",
      summary: "Shibuya Crossing & Youth Culture",
      activities: [
        {
          time: "09:00 - 11:00",
          activity: "Tranquility",
          locationName: "Meiji Jingu Shrine",
          description: "Walk through the serene forest to Tokyo's grandest Shinto shrine.",
          extendedDescription: "Dedicated to Emperor Meiji and Empress Shoken, this shrine is located in a 70-hectare forest in the middle of the city. The massive wooden Torii gates mark the entrance to a spiritual oasis. It is a striking contrast to the noise of the city just outside its borders.",
          address: "1-1 Yoyogikamizonocho, Shibuya City, Tokyo 151-8557",
          openingHours: "Sunrise to Sunset (approx 06:40 - 16:20 in Jan)",
          tips: ["Bow once when entering and leaving through the Torii gates.", "Look for the wall of Sake barrels donated by brewers nationwide."],
          category: "sightseeing",
          coordinates: { lat: 35.6764, lng: 139.6993 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Torii_at_Meiji-jingu.jpg",
          transitToNext: {
            summary: "Walk to Harajuku",
            destination: "Takeshita Street",
            options: [
              {
                mode: "walk",
                name: "Walking",
                duration: "5 mins",
                instructions: "Exit via the Harajuku Gate. Cross the street towards Harajuku Station to find the entrance to Takeshita Street."
              }
            ]
          }
        },
        {
          time: "11:30 - 13:30",
          activity: "Street Fashion",
          locationName: "Takeshita Street",
          description: "Explore the colorful hub of Harajuku fashion and crepe shops.",
          extendedDescription: "The birthplace of Japan's 'Kawaii' (cute) culture. This 400-meter street is packed with boutiques, purikura (photo booth) shops, and crepe stands. Expect loud pop music, rainbow cotton candy, and some of the most unique street fashion in the world.",
          address: "1 Chome-17 Jingumae, Shibuya City, Tokyo 150-0001",
          openingHours: "Shops typically 10:00 - 20:00",
          tips: ["Try a crepe from Marion Crepes or Santa Monica Crepes.", "Visit on a weekend to see locals dressed in cosplay or gothic lolita fashion."],
          category: "shopping",
          coordinates: { lat: 35.6716, lng: 139.7032 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Takeshita_Street_(53131946200).jpg",
          transitToNext: {
            summary: "Train to Shibuya",
            destination: "Shibuya Crossing",
            options: [
              {
                mode: "train",
                name: "JR Yamanote Line",
                duration: "2 mins (1 stop)",
                cost: "¥150",
                instructions: "From Harajuku Station, take the Yamanote Line (Outer Loop) 1 stop to Shibuya Station.",
                officialUrl: "https://www.jreast.co.jp/e/",
                imageUrl: "https://upload.wikimedia.org/wikipedia/commons/6/64/Yamanote-Line-E235.jpg"
              },
              {
                mode: "walk",
                name: "Cat Street Walk",
                duration: "20 mins",
                instructions: "Walk via Cat Street for a scenic route through fashionable backstreets."
              }
            ]
          }
        },
        {
          time: "16:00 - 18:00",
          activity: "The Scramble",
          locationName: "Shibuya Crossing",
          description: "Experience the world's busiest pedestrian crossing and see Hachiko.",
          extendedDescription: "Up to 3,000 people cross at a time during peak hours. It's organized chaos and a symbol of modern Tokyo. Don't forget to visit the statue of Hachiko, the loyal dog who waited for his owner for nine years, located just outside the Hachiko Exit.",
          address: "2 Chome-2-1 Dogenzaka, Shibuya City, Tokyo 150-0043",
          openingHours: "24 Hours",
          tips: ["The Starbucks in Tsutaya offers a great vantage point, but seats are hard to get.", "Be careful not to stop in the middle of the road for photos when the light changes."],
          category: "sightseeing",
          coordinates: { lat: 35.6595, lng: 139.7004 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Shibuya_Crossing_at_night.jpg",
          transitToNext: {
            summary: "Walk to Shibuya Sky",
            destination: "Shibuya Scramble Square",
            options: [
              {
                mode: "walk",
                name: "Walking",
                duration: "1-2 mins",
                instructions: "It is directly connected to the station. Look for the 'Shibuya Scramble Square' building entrance (East side)."
              }
            ]
          }
        },
        {
          time: "18:30 - 20:00",
          activity: "Sky Views",
          locationName: "Shibuya Sky",
          description: "Open-air observation deck with 360-degree views of the neon city.",
          extendedDescription: "Located on top of the Shibuya Scramble Square building, this open-air deck (229m high) offers arguably the best modern view of Tokyo. The glass corners provide an incredible photo opportunity. At night, the 'Crossing Light' searchlights illuminate the sky.",
          address: "2 Chome-24-12 Shibuya, Shibuya City, Tokyo 150-0002",
          openingHours: "10:00 - 22:30 (Last entry 21:20)",
          tips: ["Tickets sell out days in advance; book online.", "No tripods, hats, or loose items allowed on the roof deck."],
          category: "sightseeing",
          coordinates: { lat: 35.6585, lng: 139.7023 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/The_views_of_Shibuya_Sky_20211126_03.jpg"
        }
      ]
    },
    {
      date: "Jan 25 (Sun)",
      summary: "Old Tokyo: Asakusa & Tradition",
      activities: [
        {
          time: "09:00 - 11:30",
          activity: "Temple Visit",
          locationName: "Senso-ji Temple",
          description: "Tokyo's oldest temple. Enter through the Kaminarimon (Thunder Gate).",
          extendedDescription: "Founded in 628 AD, this is Tokyo's oldest and most colorful temple. The massive red lantern at the Kaminarimon gate is an iconic symbol of Japan. The main hall is always bustling with worshippers wafting incense smoke over themselves for good health.",
          address: "2 Chome-3-1 Asakusa, Taito City, Tokyo 111-0032",
          openingHours: "Main Hall 06:00 - 17:00 (Grounds always open)",
          tips: ["Draw an Omikuji (fortune) for 100 yen. If it's bad, tie it to the wire to leave the bad luck behind.", "Visit early (before 9 AM) to avoid massive crowds."],
          category: "sightseeing",
          coordinates: { lat: 35.7148, lng: 139.7967 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Sensoji_Kaminarimon.jpg",
          transitToNext: {
            summary: "Walk to Nakamise",
            destination: "Nakamise Street",
            options: [
              {
                mode: "walk",
                name: "Walking",
                duration: "1 min",
                instructions: "Simply turn around from the main hall. Nakamise is the shopping street leading directly to the temple."
              }
            ]
          }
        },
        {
          time: "11:30 - 13:00",
          activity: "Snacking",
          locationName: "Nakamise Shopping Street",
          description: "Traditional shopping street leading to the temple, perfect for souvenirs and snacks.",
          extendedDescription: "A 250-meter approach to the temple lined with 89 small shops. This street has served visitors for centuries. It's the best place to buy traditional souvenirs like folding fans, yukata, and local snacks.",
          address: "1 Chome-20 Asakusa, Taito City, Tokyo 111-0032",
          openingHours: "Approx 10:00 - 17:00",
          tips: ["Eat your snacks in front of the shop; walking while eating is considered rude.", "Try the Ningyo-yaki (doll-shaped sponge cakes) and Melon Pan."],
          category: "food",
          coordinates: { lat: 35.7138, lng: 139.7968 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Nakamise_Dori_%E4%BB%B2%E8%A6%8B%E4%B8%96%E9%80%9A%E3%82%8A_(191500421).jpeg",
          transitToNext: {
            summary: "Train to Skytree",
            destination: "Tokyo Skytree",
            options: [
              {
                mode: "train",
                name: "Tobu Skytree Line",
                duration: "3 mins",
                cost: "¥150",
                instructions: "From Asakusa Station, take the Tobu Line 1 stop to Tokyo Skytree Station.",
                officialUrl: "https://www.tobu.co.jp/en/",
                imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Tobu50050.JPG"
              },
              {
                mode: "walk",
                name: "Sumida River Walk",
                duration: "20 mins",
                instructions: "A pleasant walk across the Sumida River bridge. Follow signs for 'Sumida River Walk'.",
                officialUrl: "https://www.tokyo-mizumachi.jp/en/access/",
                imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Sumida_River_Walk_20200620.jpg"
              }
            ]
          }
        },
        {
          time: "14:30 - 16:30",
          activity: "Modern Icon",
          locationName: "Tokyo Skytree",
          description: "Visit the tallest structure in Japan for shopping and views.",
          extendedDescription: "At 634 meters, this broadcasting tower is the tallest structure in Japan. The Tembo Deck at 350m and the Tembo Galleria at 450m offer dizzying views. The base, Tokyo Solamachi, is a massive shopping complex with an aquarium and planetarium.",
          address: "1 Chome-1-2 Oshiage, Sumida City, Tokyo 131-0045",
          openingHours: "10:00 - 21:00",
          tips: ["Foreign tourists can buy 'Fast Skytree Tickets' to skip the regular line.", "The glass floor section on the 340th floor is thrilling."],
          category: "sightseeing",
          coordinates: { lat: 35.7101, lng: 139.8107 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Tokyo_Skytree_from_Airplane_02.jpg"
        }
      ]
    },
    {
      date: "Jan 26 (Mon)",
      summary: "Art & The Future Bay Area",
      activities: [
        {
          time: "08:00 - 10:00",
          activity: "Fresh Seafood",
          locationName: "Tsukiji Outer Market",
          description: "Wander the narrow lanes for fresh sushi breakfast and street food.",
          extendedDescription: "While the wholesale auction moved to Toyosu, the Tsukiji Outer Market remains the soul of Tokyo's food scene. Hundreds of tightly packed stalls sell fresh seafood, produce, and kitchenware. It is the best place in the world for a sushi breakfast.",
          address: "4 Chome-16-2 Tsukiji, Chuo City, Tokyo 104-0045",
          openingHours: "05:00 - 14:00 (Varies by shop)",
          tips: ["Try the Tamagoyaki (sweet rolled omelet) on a stick.", "Most shops close by early afternoon, so go for breakfast."],
          category: "food",
          coordinates: { lat: 35.6655, lng: 139.7707 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Tsukiji_Fish_Market,_Tokyo.jpg",
          transitToNext: {
            summary: "Bus to Toyosu",
            destination: "Shin-Toyosu Station",
            options: [
              {
                mode: "bus",
                name: "Toei Bus (City04)",
                duration: "20-25 mins",
                cost: "¥210",
                instructions: "Take Bus City04 from Tsukiji 3-chome bound for Toyosu. Get off at Shin-Toyosu.",
                officialUrl: "https://www.kotsu.metro.tokyo.jp/eng/bus/",
                imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Toei-Bus_B-E378.jpg"
              },
              {
                mode: "taxi",
                name: "Taxi",
                duration: "10 mins",
                cost: "¥1,500 - ¥2,000",
                instructions: "Fastest option. Hail a cab from the main street.",
                imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Toyota_JPN_TAXI_Takumi_(DAA-NTP10-AHXGN).jpg"
              }
            ]
          }
        },
        {
          time: "11:00 - 13:30",
          activity: "Digital Art",
          locationName: "teamLab Planets",
          description: "Immersive digital art museum where you walk through water and lights.",
          extendedDescription: "A museum where you become part of the art. You walk barefoot through water, crystal lights, and floating flowers. It's a sensory experience unlike any other museum. The 'Infinite Crystal Universe' and the koi pond projection are highlights.",
          address: "6 Chome-1-16 Toyosu, Koto City, Tokyo 135-0061",
          openingHours: "10:00 - 20:00",
          tips: ["Wear shorts or pants that can be rolled up (water is knee-deep).", "Advance booking is mandatory."],
          category: "sightseeing",
          coordinates: { lat: 35.6491, lng: 139.7897 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/At_teamLab_Planets_(48277798316).jpg",
          transitToNext: {
            summary: "Monorail to Odaiba",
            destination: "DiverCity Tokyo",
            options: [
              {
                mode: "train",
                name: "Yurikamome Line",
                duration: "12 mins",
                cost: "¥260",
                instructions: "From Shin-Toyosu Station, take Yurikamome towards Shimbashi. Get off at Daiba Station.",
                officialUrl: "https://www.yurikamome.co.jp/en/",
                imageUrl: "https://upload.wikimedia.org/wikipedia/commons/c/c1/Yurikamome_Series7300-7451F_Rainbow-Bridge.jpg"
              }
            ]
          }
        },
        {
          time: "15:00 - 17:00",
          activity: "Gundam Statue",
          locationName: "Odaiba DiverCity",
          description: "See the life-sized Unicorn Gundam statue transform.",
          extendedDescription: "Standing 19.7 meters tall, the Unicorn Gundam statue is a mecha-lover's dream. At specific times during the day, the armor plates shift and the statue lights up in 'Destroy Mode'. Located in front of DiverCity Tokyo Plaza.",
          address: "1 Chome-1-10 Aomi, Koto City, Tokyo 135-0064",
          openingHours: "Shows at 11:00, 13:00, 15:00, 17:00",
          tips: ["The night show features anime projections on the building wall.", "Visit the Gundam Base inside the mall for exclusive model kits."],
          category: "shopping",
          coordinates: { lat: 35.6254, lng: 139.7755 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Odaiba_Tokyo_August_2014_Gundam_008.JPG"
        }
      ]
    },
    {
      date: "Jan 27 (Tue)",
      summary: "Last Memories & Flight UO871",
      activities: [
        {
          time: "09:00 - 10:30",
          activity: "Morning Walk",
          locationName: "Imperial Palace East Gardens",
          description: "A final peaceful walk through the historic castle grounds.",
          extendedDescription: "Before heading to the airport, enjoy the crisp morning air at the Imperial Palace. It's a short walk from Tokyo Station, making it convenient. The Ninomaru Garden is particularly beautiful and offers a moment of reflection before your journey home.",
          address: "1-1 Chiyoda, Chiyoda City, Tokyo 100-8111",
          openingHours: "09:00 - 16:00 (Closed Mondays & Fridays)",
          tips: ["Luggage can be stored in coin lockers at Tokyo Station.", "Free entry."],
          category: "sightseeing",
          coordinates: { lat: 35.6852, lng: 139.7528 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Imperial_Palace_Tokyo_East_Garden_View.JPG",
          transitToNext: {
            summary: "Walk to Tokyo Station",
            destination: "Tokyo Station",
            options: [
              {
                mode: "walk",
                name: "Walking",
                duration: "10-15 mins",
                instructions: "Exit via the Otemon Gate. Walk straight towards the Marunouchi side of Tokyo Station."
              }
            ]
          }
        },
        {
          time: "11:00 - 13:00",
          activity: "Last Shopping",
          locationName: "Tokyo Station / Ginza",
          description: "Last minute souvenirs at Tokyo Character Street or Ginza.",
          extendedDescription: "Stay close to the station. Visit Tokyo Character Street for anime goods, or Daimaru Department Store for high-end sweets (KitKats, Tokyo Banana). If you have time, a quick ramen lunch at Tokyo Ramen Street is recommended.",
          address: "1 Chome-9-1 Marunouchi, Chiyoda City, Tokyo",
          openingHours: "Shops typically 10:00 - 20:00",
          tips: ["Reserve your Narita Express ticket if you haven't already.", "Bento boxes from the station are great for the train ride."],
          category: "shopping",
          coordinates: { lat: 35.6812, lng: 139.7671 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Tokyo_Station_Marunouchi_Building.jpg",
          transitToNext: {
            summary: "Narita Express to Airport",
            destination: "Narita Airport T2",
            options: [
              {
                mode: "train",
                name: "Narita Express (N'EX)",
                duration: "55-60 mins",
                cost: "¥3,070",
                instructions: "Depart from Underground Platform 5 at Tokyo Station. Ensure you are in a car bound for Narita Airport.",
                officialUrl: "https://www.jreast.co.jp/multi/en/nex/",
                imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/E259_Narita_Express.jpg"
              }
            ]
          }
        },
        {
          time: "13:30 - 14:30",
          activity: "Airport Transfer",
          locationName: "Narita Express to NRT",
          description: "Depart Tokyo Station for Narita Airport Terminal 2.",
          extendedDescription: "Take the Narita Express (N'EX) leaving around 13:30 to arrive comfortably by 14:30. Flight UO871 departs at 16:55, so arriving 2.5 hours early allows time for check-in and security.",
          address: "Tokyo Station to Narita T2",
          openingHours: "Train runs every 30 mins",
          tips: ["Ensure you get off at Terminal 2 station, not Terminal 1."],
          category: "transport",
          coordinates: { lat: 35.6812, lng: 139.7671 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/E259_Narita_Express.jpg",
          transitToNext: {
            summary: "Check-in UO871",
            destination: "HK Express Counter",
            options: [
              {
                mode: "walk",
                name: "Walking",
                duration: "5-10 mins",
                instructions: "From station, go up to Departure Hall (3F). Look for HK Express counters (usually Zone I or J)."
              }
            ]
          }
        },
        {
          time: "16:55",
          activity: "Departure",
          locationName: "Flight UO871",
          description: "Fly back to Hong Kong (HKG). Arrive 21:25.",
          extendedDescription: "Board your HK Express flight UO871. The flight duration is approximately 5 hours and 30 minutes, landing in Hong Kong Terminal 1 at 21:25.",
          address: "Narita International Airport Terminal 2",
          openingHours: "Departure 16:55",
          tips: ["Have a safe flight!"],
          category: "transport",
          coordinates: { lat: 35.7719, lng: 140.3928 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/HK_Express_A320neo_B-LCN.jpg"
        }
      ]
    }
  ]
};

export const STATIC_TRIP_PLAN_ZH: TripPlan = {
  tripName: "東京之旅 2026",
  transportTips: [
    "抵達機場後請立即購買 Suica 或 Pasmo IC 卡，以便乘坐電車和巴士。",
    "強烈建議購買 72 小時東京地鐵通票，適用於大多數地鐵線路。",
    "下載 'Japan Travel by NAVITIME' 應用程式以獲取準確的時刻表。"
  ],
  hotels: [
    {
      name: "京王廣場飯店",
      description: "位於新宿的豪華飯店，擁有迷人的城市景觀和便捷的機場巴士。",
      priceRange: "$$$",
      rating: "4.5",
      coordinates: { lat: 35.6896, lng: 139.6922 }
    },
    {
      name: "新宿格拉斯麗飯店",
      description: "位於歌舞伎町中心，以巨大的哥吉拉頭像聞名。",
      priceRange: "$$",
      rating: "4.2",
      coordinates: { lat: 35.6955, lng: 139.7018 }
    },
    {
      name: "The Millennials Shibuya",
      description: "位於澀谷的現代化高科技膠囊旅館，氛圍社交且位置極佳。",
      priceRange: "$",
      rating: "4.4",
      coordinates: { lat: 35.6616, lng: 139.7005 }
    }
  ],
  restaurants: [
  {
    name: "Sushi Dai (壽司大)",
    cuisine: "Sushi",
    description: "豐洲市場排名第一的壽司名店，主廚發辦（Omakase）套餐性價比極高，需清晨排隊。",
    priceRange: "$$$",
    coordinates: { lat: 35.6465, lng: 139.7869 },
    tabelogRating: 3.65,
    tabelogUrl: "https://tabelog.com/en/tokyo/A1313/A131307/13227096/",
    imageUrl: "https://tblg.k-img.com/restaurant/images/Rvw/321079/640x640_rect_e95256b4b96e6aabbb02d9e4e5c8469e.jpg"
  },
  {
    name: "NARISAWA",
    cuisine: "Innovative Satoyama",
    description: "亞洲五十最佳餐廳常客，將日本自然風土融入法式料理的「里山料理」先驅。",
    priceRange: "$$$$",
    coordinates: { lat: 35.6723, lng: 139.7231 },
    tabelogRating: 4.29,
    tabelogUrl: "https://tabelog.com/en/tokyo/A1306/A130603/13005423/",
    imageUrl: "https://tblg.k-img.com/restaurant/images/Rvw/227919/640x640_rect_7f8e3c6f8a9d4e2b9f1d5a3c8e7f2b1a.jpg"
  },
  {
    name: "Rokurinsha (六厘舍)",
    cuisine: "Tsukemen",
    description: "東京拉麵街的排隊王者，以超濃郁豚骨魚介湯頭與極太麵條聞名。",
    priceRange: "$",
    coordinates: { lat: 35.6800, lng: 139.7686 },
    tabelogRating: 3.77,
    tabelogUrl: "https://tabelog.com/en/tokyo/A1302/A130201/13093047/",
    imageUrl: "https://tblg.k-img.com/restaurant/images/Rvw/233456/640x640_rect_89a1f3d5e7c9b2a4f6d8e1c3a5b7f9d2.jpg"
  },
  {
    name: "Tonkatsu Maisen Aoyama (炸豬排 舞泉)",
    cuisine: "Tonkatsu",
    description: "由公共澡堂改建的傳奇店舖，招牌「黑豚腰內肉」軟嫩到可以用筷子切開。",
    priceRange: "$$",
    coordinates: { lat: 35.6661, lng: 139.7114 },
    tabelogRating: 3.44,
    tabelogUrl: "https://tabelog.com/en/tokyo/A1306/A130602/13001850/",
    imageUrl: "https://tblg.k-img.com/restaurant/images/Rvw/245678/640x640_rect_f3d7b9e2c5a8e1f4d6b3a7c9e2f5a8d1.jpg"
  },
  {
    name: "AFURI Ebisu",
    cuisine: "Ramen",
    description: "清爽系拉麵代表，金黃色的雞湯搭配高知縣產柚子汁，香氣迷人。",
    priceRange: "$",
    coordinates: { lat: 35.6482, lng: 139.7107 },
    tabelogRating: 3.49,
    tabelogUrl: "https://tabelog.com/en/tokyo/A1303/A130302/13005500/",
    imageUrl: "https://tblg.k-img.com/restaurant/images/Rvw/218945/640x640_rect_a7f5c3d9e2b6a8f1c4d7e9b2f5a8c3d6.jpg"
  },
  {
    name: "Yakiniku Jumbo Hongo (燒肉 Jumbo)",
    cuisine: "Yakiniku",
    description: "預約困難店，A5黑毛和牛的「野原燒」（像壽喜燒一樣沾蛋液吃）是必點。",
    priceRange: "$$$",
    coordinates: { lat: 35.7068, lng: 139.7606 },
    tabelogRating: 4.03,
    tabelogUrl: "https://tabelog.com/en/tokyo/A1310/A131004/13110601/",
    imageUrl: "https://tblg.k-img.com/restaurant/images/Rvw/198765/640x640_rect_c9e3f7a2d5b8f1c4e6a9d2f7b5c8e3a1.jpg"
  },
  {
    name: "Tamawarai (玉笑)",
    cuisine: "Soba",
    description: "表參道巷弄中的米其林一星，自家磨粉、手打的蕎麥麵香氣濃郁，口感極佳。",
    priceRange: "$$",
    coordinates: { lat: 35.6672, lng: 139.7049 },
    tabelogRating: 3.90,
    tabelogUrl: "https://tabelog.com/en/tokyo/A1306/A130601/13129390/",
    imageUrl: "https://tblg.k-img.com/restaurant/images/Rvw/167890/640x640_rect_d4f8a3c7e1b9f5d2a8c6e4b7f9a2d5c8.jpg"
  },
  {
    name: "Tokyo Shiba Tofuya Ukai",
    cuisine: "Kaiseki",
    description: "東京鐵塔腳下的廣闊日式庭園，提供優雅的豆腐懷石料理，適合特殊慶祝。",
    priceRange: "$$$",
    coordinates: { lat: 35.6558, lng: 139.7478 },
    tabelogRating: 3.67,
    tabelogUrl: "https://tabelog.com/en/tokyo/A1314/A131401/13019665/",
    imageUrl: "https://tblg.k-img.com/restaurant/images/Rvw/234567/640x640_rect_b8f2e6a4c9d7f1e3a5b9d8c2f6e4a7c1.jpg"
  },
  {
    name: "Ginza Kagari Roppongi Hills",
    cuisine: "Ramen",
    description: "以「雞白湯Soba」聞名，湯頭濃郁如奶油濃湯，配上時令蔬菜，擺盤如法式料理。",
    priceRange: "$",
    coordinates: { lat: 35.6604, lng: 139.7292 },
    tabelogRating: 3.54,
    tabelogUrl: "https://tabelog.com/en/tokyo/A1307/A130701/13240620/",
    imageUrl: "https://tblg.k-img.com/restaurant/images/Rvw/210987/640x640_rect_e7c5a9f3d2b8e6a1c4f9d7b3e8a5c2f6.jpg"
  },
  {
    name: "Fuunji (風雲兒)",
    cuisine: "Tsukemen",
    description: "新宿最強沾麵之一，濃厚的雞白湯魚介沾汁讓人一試成主顧。",
    priceRange: "$",
    coordinates: { lat: 35.6872, lng: 139.6976 },
    tabelogRating: 3.78,
    tabelogUrl: "https://tabelog.com/en/tokyo/A1304/A130401/13044091/",
    imageUrl: "https://tblg.k-img.com/restaurant/images/Rvw/245321/640x640_rect_f9d3b7e5a2c8f6e1d4a9c7f3b8e2d6a4.jpg"
  }
]
  days: [
    {
      date: "1月23日 (週五)",
      summary: "抵達東京 & 新宿之夜",
      activities: [
        {
          time: "15:55 - 17:00",
          activity: "班機抵達",
          locationName: "成田機場 T2",
          description: "UO870 航班抵達。辦理入境手續並領取必需品。",
          extendedDescription: "歡迎來到東京！UO870 航班降落在成田第二航廈。通過移民局並領取行李後，請前往到達大廳。這是領取 Pocket Wi-Fi/SIM 卡以及在 JR 東日本旅行服務中心購買 Suica 卡的最佳時機。",
          address: "成田國際機場第二航廈",
          openingHours: "N/A",
          tips: ["下載「Japan Official Travel App」查詢電車路線。", "在自動販賣機買瓶綠茶開始您的旅程。"],
          category: "transport",
          coordinates: { lat: 35.7719, lng: 140.3928 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Departure_lobby_of_Tokyo-Narita_Airport_Terminal_2.JPG",
          transitToNext: {
            summary: "成田特快前往新宿",
            destination: "新宿站",
            options: [
              {
                mode: "train",
                name: "成田特快 (N'EX)",
                duration: "85 分鐘",
                cost: "¥3,250",
                instructions: "跟隨 JR 線的紅色標誌 (B1F)。搭乘開往新宿/池袋方向的 N'EX。全車指定席。",
                officialUrl: "https://www.jreast.co.jp/multi/en/nex/",
                imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/JR_East_E259_Narita-Express.jpg"
              },
              {
                mode: "bus",
                name: "利木津巴士",
                duration: "100-120 分鐘",
                cost: "¥3,200",
                instructions: "在入境大廳的橘色櫃檯購票。巴士直接停靠主要飯店（如京王廣場、希爾頓等）。",
                officialUrl: "https://www.limousinebus.co.jp/guide/en/",
                imageUrl: "https://upload.wikimedia.org/wikipedia/commons/4/43/Limousine_Bus_943-40738M96_Super_Cabin_Aero_Ace.jpg"
              }
            ]
          }
        },
        {
          time: "19:00 - 20:00",
          activity: "飯店入住",
          locationName: "新宿飯店",
          description: "抵達新宿，辦理入住手續並放置行李。",
          extendedDescription: "新宿站非常巨大。如果住在京王廣場等大型飯店，請尋找「西口」搭乘飯店接駁車或計程車。辦理入住手續後，簡單梳洗一下準備出門吃晚餐。",
          address: "東京都新宿區西新宿",
          openingHours: "24 小時",
          tips: ["新宿站結構複雜，請仔細跟隨顏色的頭頂指示牌。"],
          category: "transport",
          coordinates: { lat: 35.6896, lng: 139.6922 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Shinjuku_by_night.jpg",
          transitToNext: {
            summary: "步行至回憶橫丁",
            destination: "回憶橫丁",
            options: [
              {
                mode: "walk",
                name: "步行",
                duration: "5-10 分鐘",
                instructions: "朝新宿站西口方向走。尋找 Uniqlo 大樓，巷子入口就在附近，有綠色霓虹燈。"
              }
            ]
          }
        },
        {
          time: "20:30 - 22:00",
          activity: "深夜食堂",
          locationName: "回憶橫丁",
          description: "充滿氛圍的狹窄小巷，擠滿了烤雞肉串攤位和燈籠。",
          extendedDescription: "這條狹窄的燈籠小巷被親切地稱為「小便橫丁」，將您帶回戰後的東京。長途飛行後，這裡是用烤雞肉串和啤酒作為宵夜的完美場所。氣氛煙霧繚繞，喧鬧且無比真實。",
          address: "東京都新宿區西新宿 1-2",
          openingHours: "大多數攤位營業至 23:00 或午夜",
          tips: ["大多數攤位只收現金。", "收取小菜費 (Otoshi) 是很常見的。"],
          category: "food",
          coordinates: { lat: 35.6931, lng: 139.6999 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Omoide_Yokocho,_Shinjuku_(42384563020).jpg"
        }
      ]
    },
    {
      date: "1月24日 (週六)",
      summary: "澀谷十字路口與年輕文化",
      activities: [
        {
          time: "09:00 - 11:00",
          activity: "寧靜漫步",
          locationName: "明治神宮",
          description: "穿過寧靜的森林，前往東京最宏偉的神社。",
          extendedDescription: "這座神社供奉明治天皇和昭憲皇太后，位於市中心一片 70 公頃的森林中。巨大的木製鳥居標誌著進入精神綠洲的入口。這與牆外城市的喧囂形成了鮮明的對比。",
          address: "東京都澀谷區代代木神園町 1-1",
          openingHours: "日出至日落 (1月約 06:40 - 16:20)",
          tips: ["進出鳥居時請鞠躬。", "尋找全國釀酒商捐贈的清酒桶牆。"],
          category: "sightseeing",
          coordinates: { lat: 35.6764, lng: 139.6993 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Torii_at_Meiji-jingu.jpg",
          transitToNext: {
            summary: "步行至原宿",
            destination: "竹下通",
            options: [
              {
                mode: "walk",
                name: "步行",
                duration: "5 分鐘",
                instructions: "從原宿口離開。過馬路往原宿站方向，即可找到竹下通入口。"
              }
            ]
          }
        },
        {
          time: "11:30 - 13:30",
          activity: "街頭時尚",
          locationName: "竹下通",
          description: "探索原宿時尚和可麗餅店的多彩中心。",
          extendedDescription: "日本「卡哇伊」（可愛）文化的發源地。這條 400 公尺長的街道擠滿了精品店、拍貼機店和可麗餅攤位。期待吵雜的流行音樂、彩虹棉花糖和世界上最獨特的街頭時尚。",
          address: "東京都澀谷區神宮前 1-17",
          openingHours: "商店通常 10:00 - 20:00",
          tips: ["嘗試 Marion Crepes 或 Santa Monica Crepes 的可麗餅。", "週末來訪可以看到當地人穿著 Cosplay 或哥德蘿莉時尚。"],
          category: "shopping",
          coordinates: { lat: 35.6716, lng: 139.7032 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Takeshita_Street_(53131946200).jpg",
          transitToNext: {
            summary: "電車前往澀谷",
            destination: "澀谷十字路口",
            options: [
              {
                mode: "train",
                name: "JR 山手線",
                duration: "2 分鐘 (1 站)",
                cost: "¥150",
                instructions: "從原宿站搭乘山手線（外環）1 站至澀谷站。",
                officialUrl: "https://www.jreast.co.jp/e/",
                imageUrl: "https://upload.wikimedia.org/wikipedia/commons/6/64/Yamanote-Line-E235.jpg"
              },
              {
                mode: "walk",
                name: "貓街散步",
                duration: "20 分鐘",
                instructions: "經由貓街步行，這是一條穿越時尚後街的風景路線。"
              }
            ]
          }
        },
        {
          time: "16:00 - 18:00",
          activity: "人潮洶湧",
          locationName: "澀谷十字路口",
          description: "體驗世界上最繁忙的行人穿越道並參觀忠犬八公像。",
          extendedDescription: "尖峰時段每次綠燈有多達 3,000 人穿越。這是有秩序的混亂，也是現代東京的象徵。別忘了參觀位於八公出口外的忠犬八公像，這隻忠犬等待主人長達九年。",
          address: "東京都澀谷區道玄坂 2-2-1",
          openingHours: "24 小時",
          tips: ["Tsutaya 的星巴克視野很好，但很難找到位子。", "綠燈時請注意不要為了拍照而停在路中間。"],
          category: "sightseeing",
          coordinates: { lat: 35.6595, lng: 139.7004 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Shibuya_Crossing_at_night.jpg",
          transitToNext: {
            summary: "步行至 Shibuya Sky",
            destination: "Shibuya Scramble Square",
            options: [
              {
                mode: "walk",
                name: "步行",
                duration: "1-2 分鐘",
                instructions: "與車站直接相連。尋找「Shibuya Scramble Square」大樓入口（東側）。"
              }
            ]
          }
        },
        {
          time: "18:30 - 20:00",
          activity: "高空美景",
          locationName: "Shibuya Sky",
          description: "露天展望台，可 360 度欣賞霓虹閃爍的城市。",
          extendedDescription: "位於 Shibuya Scramble Square 大樓頂層（229 公尺高），這個露天甲板可以說是東京最佳的現代景觀。玻璃角落提供了令人難以置信的拍照機會。到了晚上，「Crossing Light」探照燈會照亮天空。",
          address: "東京都澀谷區澀谷 2-24-12",
          openingHours: "10:00 - 22:30 (最後入場 21:20)",
          tips: ["門票通常會提前幾天售罄；請線上預訂。", "屋頂甲板不允許攜帶三腳架、帽子或鬆散物品。"],
          category: "sightseeing",
          coordinates: { lat: 35.6585, lng: 139.7023 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/The_views_of_Shibuya_Sky_20211126_03.jpg"
        }
      ]
    },
    {
      date: "1月25日 (週日)",
      summary: "老東京：淺草與傳統",
      activities: [
        {
          time: "09:00 - 11:30",
          activity: "參拜",
          locationName: "淺草寺",
          description: "東京最古老的寺廟，穿越著名的雷門。",
          extendedDescription: "這座東京最古老、色彩最豐富的寺廟建於西元 628 年。雷門巨大的紅燈籠是日本的標誌性象徵。正殿總是擠滿了信徒，將香爐的煙霧撥向自己以祈求健康。",
          address: "東京都台東區淺草 2-3-1",
          openingHours: "正殿 06:00 - 17:00 (境內全天開放)",
          tips: ["抽一支御神籤（100 日圓）。如果是兇，請把它綁在繩子上以留下厄運。", "盡早（早上 9 點前）參觀以避開大量人群。"],
          category: "sightseeing",
          coordinates: { lat: 35.7148, lng: 139.7967 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Sensoji_Kaminarimon.jpg",
          transitToNext: {
            summary: "步行至仲見世",
            destination: "仲見世商店街",
            options: [
              {
                mode: "walk",
                name: "步行",
                duration: "1 分鐘",
                instructions: "從正殿轉身即可。仲見世是直接通往寺廟的購物街。"
              }
            ]
          }
        },
        {
          time: "11:30 - 13:00",
          activity: "小吃",
          locationName: "仲見世商店街",
          description: "通往寺廟的傳統商店街，非常適合購買紀念品和小吃。",
          extendedDescription: "一條長 250 公尺的參道，兩旁林立著 89 家小店。這條街已經為遊客服務了幾個世紀。這裡是購買摺扇、浴衣和當地小吃等傳統紀念品的最佳場所。",
          address: "東京都台東區淺草 1-20",
          openingHours: "約 10:00 - 17:00",
          tips: ["請在店門口吃完小吃；邊走邊吃被認為是不禮貌的。", "試試人形燒（人形海綿蛋糕）和波羅麵包。"],
          category: "food",
          coordinates: { lat: 35.7138, lng: 139.7968 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Nakamise_Dori_%E4%BB%B2%E8%A6%8B%E4%B8%96%E9%80%9A%E3%82%8A_(191500421).jpeg",
          transitToNext: {
            summary: "電車前往晴空塔",
            destination: "東京晴空塔",
            options: [
              {
                mode: "train",
                name: "東武晴空塔線",
                duration: "3 分鐘",
                cost: "¥150",
                instructions: "從淺草站搭乘東武線 1 站至東京晴空塔站。",
                officialUrl: "https://www.tobu.co.jp/en/",
                imageUrl: "https://upload.wikimedia.org/wikipedia/commons/9/9b/Tobu_50050_series_EMU_011.JPG"
              },
              {
                mode: "walk",
                name: "隅田川步道",
                duration: "20 分鐘",
                instructions: "穿過隅田川大橋的愉快步行路線。跟隨「SUMIDA RIVER WALK」標誌。",
                officialUrl: "https://www.tokyo-mizumachi.jp/en/access/",
                imageUrl: "https://upload.wikimedia.org/wikipedia/commons/e/eb/Sumida_River_Walk_entrance_-_July_6_2020.jpeg"
              }
            ]
          }
        },
        {
          time: "14:30 - 16:30",
          activity: "現代地標",
          locationName: "東京晴空塔",
          description: "參觀日本最高的建築，享受購物和美景。",
          extendedDescription: "這座廣播塔高 634 公尺，是日本最高的建築。350 公尺的天望甲板和 450 公尺的天望迴廊提供令人眩暈的景色。底部的東京晴空街道是一個巨大的購物中心，設有水族館和天文館。",
          address: "東京都墨田區押上 1-1-2",
          openingHours: "10:00 - 21:00",
          tips: ["外國遊客可以購買「快速晴空塔門票」以跳過排隊。", "340 樓的玻璃地板區非常刺激。"],
          category: "sightseeing",
          coordinates: { lat: 35.7101, lng: 139.8107 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Tokyo_Skytree_from_Airplane_02.jpg"
        }
      ]
    },
    {
      date: "1月26日 (週一)",
      summary: "藝術與未來海灣區",
      activities: [
        {
          time: "08:00 - 10:00",
          activity: "新鮮海鮮",
          locationName: "築地場外市場",
          description: "在狹窄的巷弄中漫步，享用新鮮的壽司早餐和街頭美食。",
          extendedDescription: "雖然批發拍賣已移至豐洲，但築地場外市場仍然是東京美食界的靈魂。數百個擁擠的攤位出售新鮮海鮮、農產品和廚具。這裡是世界上享用壽司早餐的最佳地點。",
          address: "東京都中央區築地 4-16-2",
          openingHours: "05:00 - 14:00 (因店而異)",
          tips: ["試試玉子燒串（甜的厚蛋燒）。", "大多數商店下午很早就關門，所以早餐時段去最好。"],
          category: "food",
          coordinates: { lat: 35.6655, lng: 139.7707 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Tsukiji_Fish_Market,_Tokyo.jpg",
          transitToNext: {
            summary: "巴士前往豐洲",
            destination: "新豐洲站",
            options: [
              {
                mode: "bus",
                name: "都營巴士 (City04)",
                duration: "20-25 分鐘",
                cost: "¥210",
                instructions: "從築地三丁目搭乘開往豐洲方向的 City04 巴士。在新豐洲下車。",
                officialUrl: "https://www.kotsu.metro.tokyo.jp/eng/bus/",
                imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Toei-Bus_B-E378.jpg"
              },
              {
                mode: "taxi",
                name: "計程車",
                duration: "10 分鐘",
                cost: "¥1,500 - ¥2,000",
                instructions: "最快的選擇。在主要街道上招計程車。",
                imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Toyota_JPN_TAXI_Takumi_(DAA-NTP10-AHXGN).jpg"
              }
            ]
          }
        },
        {
          time: "11:00 - 13:30",
          activity: "數位藝術",
          locationName: "teamLab Planets",
          description: "沉浸式數位藝術博物館，您可以在水中和光影中行走。",
          extendedDescription: "一個讓您成為藝術一部分的博物館。您赤腳走過水、水晶燈和漂浮的花朵。這是與其他博物館截然不同的感官體驗。「無窮無盡的水晶宇宙」和錦鯉池投影是亮點。",
          address: "東京都江東區豐洲 6-1-16",
          openingHours: "10:00 - 20:00",
          tips: ["穿著短褲或可以捲起的褲子（水深及膝）。", "必須提前預訂。"],
          category: "sightseeing",
          coordinates: { lat: 35.6491, lng: 139.7897 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/At_teamLab_Planets_(48277798316).jpg",
          transitToNext: {
            summary: "單軌列車前往台場",
            destination: "DiverCity Tokyo",
            options: [
              {
                mode: "train",
                name: "百合海鷗號",
                duration: "12 分鐘",
                cost: "¥260",
                instructions: "從新豐洲站搭乘百合海鷗號往新橋方向。在台場站下車。",
                officialUrl: "https://www.yurikamome.co.jp/en/",
                imageUrl: "https://upload.wikimedia.org/wikipedia/commons/c/c1/Yurikamome_Series7300-7451F_Rainbow-Bridge.jpg"
              }
            ]
          }
        },
        {
          time: "15:00 - 17:00",
          activity: "鋼彈",
          locationName: "台場 DiverCity",
          description: "觀看實物大小的獨角獸鋼彈變身。",
          extendedDescription: "獨角獸鋼彈像高 19.7 公尺，是機甲迷的夢想。在白天的特定時間，裝甲板會移動，雕像會亮起「毀滅模式」。位於 DiverCity Tokyo Plaza 前。",
          address: "東京都江東區青海 1-1-10",
          openingHours: "演出時間 11:00, 13:00, 15:00, 17:00",
          tips: ["晚上的表演以建築物牆壁上的動畫投影為特色。", "參觀購物中心內的鋼彈基地，購買獨家模型套件。"],
          category: "shopping",
          coordinates: { lat: 35.6254, lng: 139.7755 },
          imageUrl: "https://commons.wikimedia.org/wiki/File:Diver_City_Tokyo_(20873006931).jpg"
        }
      ]
    },
    {
      date: "1月27日 (週二)",
      summary: "最終回憶與 UO871 返航",
      activities: [
        {
          time: "09:00 - 10:30",
          activity: "早安散步",
          locationName: "皇居東御苑",
          description: "在前往機場前，最後一次漫步於歷史悠久的城堡庭園。",
          extendedDescription: "在前往機場之前，享受皇居清新的早晨空氣。距離東京站很近，非常方便。二之丸庭園特別美麗，為您的旅程畫上寧靜的句點。",
          address: "東京都千代田區千代田 1-1",
          openingHours: "09:00 - 16:00 (週一和週五關閉)",
          tips: ["行李可以寄存在東京站的投幣式儲物櫃。", "免費入場。"],
          category: "sightseeing",
          coordinates: { lat: 35.6852, lng: 139.7528 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Imperial_Palace_Tokyo_East_Garden_View.JPG",
          transitToNext: {
            summary: "步行至東京站",
            destination: "東京站",
            options: [
              {
                mode: "walk",
                name: "步行",
                duration: "10-15 分鐘",
                instructions: "從大手門出口離開。直走往東京站丸之內方向。"
              }
            ]
          }
        },
        {
          time: "11:00 - 13:00",
          activity: "最後採購",
          locationName: "東京站 / 銀座",
          description: "在東京動漫人物街或銀座購買最後的紀念品。",
          extendedDescription: "留在車站附近。參觀東京動漫人物街購買動漫商品，或去大丸百貨購買高級甜點（KitKat、東京香蕉）。如果有時間，推薦去東京拉麵街吃碗拉麵當午餐。",
          address: "東京都千代田區丸之內 1-9-1",
          openingHours: "商店通常 10:00 - 20:00",
          tips: ["如果您還沒有預訂成田特快車票，請先預訂。", "車站的便當非常適合在火車上享用。"],
          category: "shopping",
          coordinates: { lat: 35.6812, lng: 139.7671 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Tokyo_Station_Marunouchi_Building.jpg",
          transitToNext: {
            summary: "成田特快前往機場",
            destination: "成田機場 T2",
            options: [
              {
                mode: "train",
                name: "成田特快 (N'EX)",
                duration: "55-60 分鐘",
                cost: "¥3,070",
                instructions: "從東京站地下 5 樓月台出發。確保您在開往成田機場的車廂。",
                officialUrl: "https://www.jreast.co.jp/multi/en/nex/",
                imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/JR_East_E259_Narita-Express_1920x1280.jpg"
              }
            ]
          }
        },
        {
          time: "13:30 - 14:30",
          activity: "前往機場",
          locationName: "成田特快前往 NRT",
          description: "從東京站出發前往成田機場第二航廈。",
          extendedDescription: "搭乘約 13:30 出發的成田特快 (N'EX)，於 14:30 舒適抵達。UO871 航班於 16:55 起飛，提早 2.5 小時抵達可預留充足的辦理登機和安檢時間。",
          address: "東京站 至 成田 T2",
          openingHours: "火車每 30 分鐘一班",
          tips: ["請確保在第二航廈站下車，而不是第一航廈。"],
          category: "transport",
          coordinates: { lat: 35.6812, lng: 139.7671 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/JR_East_E259_Narita-Express_1920x1280.jpg",
          transitToNext: {
            summary: "辦理 UO871 登機",
            destination: "香港快運櫃台",
            options: [
              {
                mode: "walk",
                name: "步行",
                duration: "5-10 分鐘",
                instructions: "從車站上至 3 樓出發大廳。尋找香港快運櫃台（通常是 I 或 J 區）。"
              }
            ]
          }
        },
        {
          time: "16:55",
          activity: "返程",
          locationName: "航班 UO871",
          description: "飛回香港 (HKG)。抵達時間 21:25。",
          extendedDescription: "搭乘香港快運 UO871 航班。飛行時間約 5 小時 30 分鐘，於 21:25 降落在香港第一航廈。",
          address: "成田國際機場第二航廈",
          openingHours: "起飛 16:55",
          tips: ["祝您旅途愉快！"],
          category: "transport",
          coordinates: { lat: 35.7719, lng: 140.3928 },
          imageUrl: "https://commons.wikimedia.org/wiki/Special:FilePath/Airbus_A321-231_%E2%80%98B-LED%E2%80%99_Hong_Kong_Express.jpg"
        }
      ]
    }
  ]
};